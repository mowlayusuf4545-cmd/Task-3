# Causality Assessment of an Adverse Drug Reaction (ADR)
**Pharmacovigilance Internship Task 3**

## 1. Objective
To assess whether a patient's suspected adverse drug reaction is related to a medicine by reviewing the timing of the reaction, improvement after stopping the medicine, possible alternative causes, and available evidence.

## 2. Illustrative Patient Case
**Educational example only:** This is a fictional case created for learning, not a real patient's record.

A 45-year-old woman was prescribed amoxicillin for a bacterial infection. On the third day of treatment, she developed an itchy red rash on her trunk and arms. She contacted her healthcare provider, who assessed the reaction and advised stopping the suspected medicine. The rash gradually improved over the next few days. The medicine was not restarted, and no deliberate rechallenge was attempted.

## 3. Key Case Details

| Assessment item | Finding |
|---|---|
| Suspected medicine | Amoxicillin |
| Suspected reaction | Itchy red skin rash |
| Time to onset | Approximately 3 days after treatment began |
| Action taken | Stopped following clinical assessment |
| Dechallenge | Symptoms improved after withdrawal |
| Rechallenge | Not performed |
| Alternative causes | No clear alternative identified in this fictional history |
| Outcome | Rash improved over the next few days |

## 4. Causality Assessment

The assessment considers:
1. **Temporal relationship:** Did the reaction begin after the medicine was started?
2. **Dechallenge:** Did the reaction improve after the suspected medicine was withdrawn?
3. **Alternative causes:** Could the illness, another medicine, or another condition explain the symptoms?
4. **Rechallenge or other evidence:** Is additional evidence available? Rechallenge is not required and should not be deliberately attempted when it could put the patient at risk.

### WHO–UMC assessment: Probable/Likely
For this illustrative case, the suspected relationship may be classified as **Probable/Likely** under the WHO–UMC approach if clinical review finds no reasonable alternative explanation. The timing is plausible, and the rash improved after withdrawal. Rechallenge is not necessary for this category.

This is a training assessment, not a definitive diagnosis. A real case requires complete clinical information and assessment by an appropriately qualified healthcare professional.

## 5. Naranjo Algorithm: Important Note
The Naranjo algorithm is another structured method used to assess the likelihood that a drug caused an adverse event. It uses a series of questions and a numerical score. A score should only be calculated when the required details are available; missing information should not be guessed. WHO–UMC and Naranjo are different methods and their categories are not interchangeable.

## 6. Severity, Seriousness, and Expectedness
- **Severity** describes how intense the reaction is (for example, mild, moderate, or severe).
- **Seriousness** is based on criteria such as death, a life-threatening event, hospital admission or prolongation, significant disability, congenital anomaly, or another medically important event.
- **Expectedness** asks whether the reaction is consistent with the known product information.

In this fictional case, the rash appears mild based on the limited description. Seriousness and expectedness must be determined from the full clinical record and applicable reporting requirements; they should not be assumed solely from the word “rash.”

## 7. Recommended Pharmacist Actions
1. Record the suspected medicine, dose, route, start date, reaction onset, relevant history, and outcome.
2. Refer the patient for clinical assessment, especially if the rash is spreading or worsening.
3. Advise urgent medical attention for breathing difficulty, swelling of the face or tongue, fainting, blistering, skin peeling, painful rash, or sores involving the mouth or eyes.
4. Do not recommend restarting the suspected medicine or performing a rechallenge without specialist clinical direction.
5. Document the suspected reaction in the medical record and communicate it to the treating team.
6. Submit an ADR report through the appropriate pharmacovigilance pathway when indicated, even if causality is not certain.

## 8. Conclusion
This fictional case describes an itchy rash that developed after amoxicillin was started and improved after the medicine was stopped. These features support a drug relationship. If clinical review confirms that other explanations are unlikely, the WHO–UMC category **Probable/Likely** may be appropriate. In practice, causality assessment depends on complete patient information, clinical judgement, and applicable pharmacovigilance procedures.

## References
1. World Health Organization–Uppsala Monitoring Centre (WHO–UMC). *The use of the WHO–UMC system for standardised case causality assessment*.
2. Naranjo CA, Busto U, Sellers EM, et al. A method for estimating the probability of adverse drug reactions. *Clinical Pharmacology & Therapeutics*. 1981;30(2):239–245.
3. Indian Pharmacopoeia Commission. *Pharmacovigilance Programme of India (PvPI)*: official ADR reporting and pharmacovigilance resources.

---
**Task ID:** task3  
**Topic:** Causality Assessment
